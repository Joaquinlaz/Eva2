package com.evaluacion2.Clientes.clientes.service;

import com.evaluacion2.Clientes.clientes.model.Cliente;
import com.evaluacion2.Clientes.clientes.repository.ClienteRepository;
import com.evaluacion2.Clientes.clientes.service.ClienteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Integration-style test using Spring Boot context with a mocked repository.
 */
@SpringBootTest
public class ClienteServiceTest {

    @MockBean
    private ClienteRepository clienteRepository;

    @Autowired
    private ClienteService clienteService;

    private Cliente sampleCliente;
    private Date now;

    @BeforeEach
    void setUp() {
        now = new Date();
        sample  Cliente = new Cliente();
        sampleCliente.setId(1L);
        sampleCliente.setUsername("john_doe");
        sampleCliente.setRun("12345678-9");
        sampleCliente.setCorreo("john@example.com");
        sampleCliente.setCiudad("Santiago");
        sampleCliente.setFechaNacimiento(now);
        sampleCliente.setFechaRegistro(now);
        sampleCliente.setAddress("123 Main St");
    }

    @Test
    void testSaveCliente() {
        when(clienteRepository.save(sampleCliente)).thenReturn(sampleCliente);

        Cliente result = clienteService.saveCliente(sampleCliente);

        assertEquals(sampleCliente, result);
        verify(clienteRepository, times(1)).save(sampleCliente);
    }

    @Test
    void testGetClienteByIdFound() {
        when(clienteRepository.findById(1L)).thenReturn(Optional.of(sampleCliente));

        Cliente result = clienteService.getClienteById(1L);

        assertNotNull(result);
        assertEquals(sampleCliente, result);
        verify(clienteRepository, times(1)).findById(1L);
    }

    @Test
    void testGetClienteByIdNotFound() {
        when(clienteRepository.findById(2L)).thenReturn(Optional.empty());

        Cliente result = clienteService.getClienteById(2L);

        assertNull(result);
        verify(clienteRepository, times(1)).findById(2L);
    }

    @Test
    void testDeleteCliente() {
        doNothing().when(clienteRepository).deleteById(1L);

        clienteService.deleteCliente(1L);

        verify(clienteRepository, times(1)).deleteById(1L);
    }

    @Test
    void testGetAllClientes() {
        when(clienteRepository.findAll()).thenReturn(Arrays.asList(sampleCliente));

        List<Cliente> result = clienteService.getAllClientes();

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(sampleCliente, result.get(0));
        verify(clienteRepository, times(1)).findAll();
    }

    @Test
    void testFindByUsername() {
        when(clienteRepository.findByUsername("john_doe")).thenReturn(Arrays.asList(sampleCliente));

        List<Cliente> result = clienteService.findByUsername("john_doe");

        assertFalse(result.isEmpty());
        assertEquals(sampleCliente, result.get(0));
        verify(clienteRepository, times(1)).findByUsername("john_doe");
    }

    @Test
    void testFindByUsernameEmpty() {
        when(clienteRepository.findByUsername("unknown")).thenReturn(Collections.emptyList());

        List<Cliente> result = clienteService.findByUsername("unknown");

        assertTrue(result.isEmpty());
        verify(clienteRepository, times(1)).findByUsername("unknown");
    }

    @Test
    void testFindByCiudad() {
        when(clienteRepository.findByCiudad("Santiago")).thenReturn(Arrays.asList(sampleCliente));

        List<Cliente> result = clienteService.findByCiudad("Santiago");

        assertFalse(result.isEmpty());
        assertEquals(sampleCliente, result.get(0));
        verify(clienteRepository, times(1)).findByCiudad("Santiago");
    }

    @Test
    void testFindByFechaRegistroBetween() {
        Date start = new Date(now.getTime() - 1000000);
        Date end = new Date(now.getTime() + 1000000);
        when(clienteRepository.findByFechaRegistroBetween(start, end)).thenReturn(Arrays.asList(sampleCliente));

        List<Cliente> result = clienteService.findByFechaRegistroBetween(start, end);

        assertFalse(result.isEmpty());
        assertEquals(sampleCliente, result.get(0));
        verify(clienteRepository, times(1)).findByFechaRegistroBetween(start, end);
    }
}

